import os
import pytest
from file_manager import FileManager

@pytest.fixture
def temp_dir(tmp_path):
    return tmp_path / "test_user"

def test_create_user_folder(temp_dir):
    fm = FileManager(str(temp_dir.parent))
    result = fm.create_user_folder("test_user")
    assert os.path.exists(result)
    assert os.path.isdir(result)

def test_save_file(temp_dir):
    fm = FileManager(str(temp_dir.parent))
    user_folder = fm.create_user_folder("test_user")
    fake_data = b"Hello world"
    path = fm.save_file(user_folder, "test.docx", fake_data)
    assert os.path.exists(path)
    with open(path, "rb") as f:
        assert f.read() == fake_data
